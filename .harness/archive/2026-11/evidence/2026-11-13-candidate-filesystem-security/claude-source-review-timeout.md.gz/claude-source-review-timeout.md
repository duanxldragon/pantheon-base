# Original user task
Complete Pantheon Base closeout, fix CI and GitHub Security alerts, merge, clean Base branches/worktrees, and publish v0.18.8 after final gates pass.

# Backend and final prompt
Backend: locally installed Claude Code via claude -p, read-only source review.

```text
You are an independent CODE/security reviewer, read-only, for Pantheon Base. Do not edit any repository files or dismiss alerts. User authorized final CI/security repair then immutable v0.18.8 release. Review exact frozen four-source snapshot e5933880b5fc4f7b7a419c0b8b36e5490f2acddb, parent ae2fa81d9903d63b4bec8f01d61082f48a999e2f, repository D:/workspace/go/pantheon-platform/.wt-base-smoke-readiness. Use git diff parent tree for these four paths only: frontend/tests/smoke/system/system-pages-helpers.ts, scripts/foundation-release/build-candidate-artifact.mjs, scripts/foundation-release/candidate-descriptor.mjs, scripts/foundation-release/candidate-artifact.test.mjs. Source bytes frozen; governance/evidence unstaged draft and will be separately reviewed later. Read AGENTS.md authority and relevant candidate boundary contract.
Root cause smoke: Locator.evaluate timeout options mistakenly second arg; new undefined inserts second data arg so options third. Real Playwright1.65.0 exact AST helper browser proof in D:/workspace/go/pantheon-platform/audit-artifacts/base-final-closeout-2026-11-13/sr509: original30s fail, fixed2.17s pass, known/populated pass, unknown persistent rejected, source unchanged after checks; strictTS with actual PWtypes and ESLint zero.
GitHub9 HIGH CodeQL js/file-system-race alerts100-108 exact original locations and source strings/final hashes/manualthreat evidence in parent audit directory/sec509/security-source-evidence.json. New shared open-first fd reader handles bounded regularfiles, fstatBigint stamps, observed path/ancestor checks, paired handles through digest checks, closure attempts all handles while preserving original error, no claimed atomic Windows namespace guarantee. Tests candidate68nodes65pass3Windows leaf-symlink-capability skips0fail, foundation57/57; actual sameinode ancestorjunction and saved-byte/rename/cleanup negatives retained. Syntax/securitypatterns/diffcheck pass. Official CodeQL query reference retained but local CodeQLCLI/LSP not exposed; don't claim those tools executed. Hosted same-rule closure mandatory after merge. Need assess substantive code correctness, guard preservation, cross-platform behavior, test adequacy, all9 sink mappings including #107 exclusive-fd recreated write. No suppressions or gate weakening. Fresh1176-source candidate production/consumer build ongoing; review formal source only now, overall release still pending final combined review/candidate/CI/cleanmain/assets.
Return concise report with exact tree+parent, severity-ranked findings with file line references or zero findings, overall CODE verdict APPROVE / CHANGES REQUESTED based on actual source correctness and available meaningful evidence, validation limitations (no LSP/ASTtool; Windows3 cases deferred toLinuxCI). No blanket demand for unavailable tooling beyond repository policy. Approval is source scope only, NOT official release readiness. Explain any mustfix clearly. Do not mutate source or files; return report text only.
```

# Raw CLI output

```text
"ark-code-latest" isn't described by this version's model catalog; update Claude Code, or map it with behavesAs on a modelPicker row (or modelOverrides, if it is a provider id of a model this version knows). Until then auto-compact keeps this session within 200k tokens (the context window it assumes); if the model accepts more, append [1m] to the model name for 1M, or set CLAUDE_CODE_MAX_CONTEXT_TOKENS to its real window; CLAUDE_CODE_DISABLE_UNKNOWN_MODEL_WINDOW_ENFORCEMENT=1 restores the previous wait-for-the-API behavior.
[claude-code:unrecognized_model] {"model":"ark-code-latest","query_source":"sdk"}

```

```json
{
  "status": "terminated-without-verdict",
  "reason": "Owned read-only local advisor exceeded 10 minutes with only configured-model warning; independent native verifier review continues",
  "elapsedSeconds": 806.0
}

```

# Concise summary

No review verdict was returned during 806 seconds. The exclusive, verified process was terminated; diagnostic evidence only. This run does not constitute approval and made no source changes.

# Action items / next steps

Retain independent native verifier and architect reports. Finish consumer build and governance bindings, then require final hosted CI, automatic CodeQL closure and verified v0.18.8 publication.
