"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pageEmptyTexts = void 0;
exports.expectPageBodyReady = expectPageBodyReady;
exports.pageEmptyTexts = [
    '暂无数据',
    '当前筛选范围内没有可展示的数据',
    '当前筛选下暂无岗位',
    '暂无系统设置',
    '请选择左侧字典类型后维护字典项',
    '暂无字典类型',
    '暂无字典项',
    '暂无登录日志',
    '暂无会话数据',
];
async function expectPageBodyReady(page) {
    const readySelector = [
        '.arco-table',
        '.arco-empty',
        '.setting-page__group-nav-grid',
        '.setting-page__config-card',
        '.generator-wizard__steps',
    ].join(', '); // keep in sync with the original per-indicator locators
    // Body readiness must retry while the page settles: one-shot count()
    // snapshots race table/empty mounting on slow environments and turn the
    // system-pages smoke loop flaky.
    await expect(page.locator(readySelector).filter({ visible: true }).first()).toBeVisible();
    // When an empty state is on screen, its message must be a known per-page
    // empty text. Read the text through evaluate() with a short timeout:
    // innerText() waits for element stability, and Arco's transient loading
    // empty state animates indefinitely, so the raw action would burn the
    // whole 30s test budget instead of letting toPass retry after the table
    // mounts and the empty detaches.
    await expect(async () => {
        const emptyNode = page.locator('.arco-empty').first();
        if (!(await emptyNode.isVisible())) {
            return;
        }
        const emptyText = await emptyNode.evaluate((element) => element.textContent ?? '', undefined, {
            timeout: 2000,
        });
        expect(exports.pageEmptyTexts.some((text) => emptyText.includes(text))).toBeTruthy();
    }).toPass();
}
