'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { createRequire } = require('node:module');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '../../..');
const worktree = path.join(root, '.wt-base-smoke-readiness');
const relative = 'frontend/tests/smoke/system/system-pages-helpers.ts';
const helperPath = path.join(worktree, relative);
const deps = path.join(root, 'audit-artifacts/base-final-closeout-2026-11-13/dependency-validation/source/frontend/node_modules');
const depRequire = createRequire(path.join(deps, '../package.json'));
const ts = depRequire('typescript');
const pw = depRequire('@playwright/test');
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const baseline = execFileSync('D:/Git/mingw64/bin/git.exe', ['show', 'ae2fa81d:' + relative], { cwd: worktree, encoding: 'utf8' });
const patched = fs.readFileSync(helperPath, 'utf8');
const outputs = [];
function log(record) { outputs.push(record); console.log(JSON.stringify(record)); }
function extract(source, name) {
  const ast = ts.createSourceFile(helperPath, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const selected = ast.statements.filter(statement =>
    ts.isFunctionDeclaration(statement) && statement.name?.text === 'expectPageBodyReady' ||
    ts.isVariableStatement(statement) && statement.declarationList.declarations.some(d => ts.isIdentifier(d.name) && d.name.text === 'pageEmptyTexts'));
  assert.equal(selected.length, 2);
  const text = selected.map(statement => statement.getText(ast)).join('\n\n');
  const compiled = ts.transpileModule(text, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2023 } }).outputText;
  fs.writeFileSync(path.join(__dirname, name + '.ts'), `// Extracted from ${helperPath}; whole-source SHA256 ${hash(source)}\n` + text + '\n');
  fs.writeFileSync(path.join(__dirname, name + '.cjs'), compiled);
  log({ kind: 'source', variant: name, file: helperPath, sourceSHA256: hash(source), selectedSHA256: hash(text), transpiledSHA256: hash(compiled), selectedLines: selected.map(s => ast.getLineAndCharacterOfPosition(s.getStart(ast)).line + 1) });
  return timeout => {
    const exports = {};
    // Harness-only toPass deadline: expect.configure supports assertion timeout but not toPass timeout.
    // Forward all native matchers; add the external case budget only to native toPass options.
    const nativeExpect = pw.expect.configure({ timeout: 10000 });
    const boundedExpect = (...args) => {
      const matchers = nativeExpect(...args);
      if (typeof args[0] !== 'function') return matchers;
      return new Proxy(matchers, { get(target, key) {
        if (key === 'toPass') return options => target.toPass({ timeout, ...options });
        return typeof target[key] === 'function' ? target[key].bind(target) : target[key];
      }});
    };
    new Function('expect', 'exports', compiled)(boundedExpect, exports);
    return exports.expectPageBodyReady;
  };
}
async function diagnostics() {
  const current = fs.readFileSync(path.join(__dirname, 'current.ts'), 'utf8');
  const typed = `import { expect, type Page } from '${pathToFileURL(depRequire.resolve('@playwright/test')).href.replace(/\/index\.js$/, '')}';\n` + current;
  // TypeScript module resolution accepts an absolute filesystem package path.
  const typedSource = typed.replace(pathToFileURL(depRequire.resolve('@playwright/test')).href.replace(/\/index\.js$/, ''), path.dirname(depRequire.resolve('@playwright/test')).replaceAll('\\', '/'));
  const typedPath = path.join(__dirname, 'typed.ts');
  fs.writeFileSync(typedPath, typedSource);
  const program = ts.createProgram([typedPath], { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ESNext, moduleResolution: ts.ModuleResolutionKind.Bundler, strict: true, noEmit: true, skipLibCheck: true, types: [], lib: ['lib.es2023.d.ts', 'lib.dom.d.ts'] });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  const printed = ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCurrentDirectory: () => __dirname, getCanonicalFileName: f => f, getNewLine: () => '\n' });
  fs.writeFileSync(path.join(__dirname, 'typescript.txt'), printed || 'PASS: strict TypeScript check of exact AST-extracted helper and pageEmptyTexts with installed Playwright1.65.0 types.\n');
  assert.equal(diagnostics.length, 0, printed);
  const configPath = path.join(worktree, 'frontend/eslint.config.js');
  const configSource = fs.readFileSync(configPath, 'utf8').replace(/from '([^']+)'/g, (_, packageName) => `from '${pathToFileURL(depRequire.resolve(packageName)).href}'`);
  const { default: config } = await import('data:text/javascript;base64,' + Buffer.from(configSource).toString('base64'));
  const { ESLint } = depRequire('eslint');
  const eslint = new ESLint({ cwd: path.join(worktree, 'frontend'), overrideConfigFile: true, overrideConfig: config });
  const results = await eslint.lintFiles([helperPath]);
  const formatted = await (await eslint.loadFormatter('stylish')).format(results);
  fs.writeFileSync(path.join(__dirname, 'eslint.txt'), formatted || 'PASS: exact worktree helper under unmodified repo ESLint configuration.\n');
  assert.equal(results.reduce((total, result) => total + result.errorCount + result.warningCount, 0), 0, formatted);
  const diff = execFileSync('D:/Git/mingw64/bin/git.exe', ['diff', '--check'], { cwd: worktree, encoding: 'utf8' });
  fs.writeFileSync(path.join(__dirname, 'diff-check.txt'), diff || 'PASS: git diff --check\n');
  fs.writeFileSync(path.join(__dirname, 'patch.diff'), execFileSync('D:/Git/mingw64/bin/git.exe', ['diff', '--', relative], { cwd: worktree, encoding: 'utf8' }));
  log({ kind: 'diagnostics', eslint: 'PASS (exact worktree file, exact repo rules)', typescript: 'PASS (strict exact extracted helper, native Playwright types)', diffCheck: 'PASS' });
}
function interceptDetachment(page, calls) {
  let detached = false;
  return new Proxy(page, { get(target, key) {
    if (key !== 'locator') return typeof target[key] === 'function' ? target[key].bind(target) : target[key];
    return (...args) => {
      const real = target.locator(...args);
      if (args[0] !== '.arco-empty') return real;
      calls.attempts += 1;
      const wrap = locator => new Proxy(locator, { get(instance, method) {
        if (method === 'first') return () => wrap(instance.first());
        if (method === 'isVisible') return async () => {
          const visible = await instance.isVisible();
          calls.visibility.push(visible);
          if (visible && !detached) {
            await target.evaluate(() => { document.querySelector('.arco-empty').remove(); document.querySelector('.arco-table').style.display = 'table'; });
            detached = true;
            calls.detachedAfterVisible = true;
          }
          return visible;
        };
        if (method === 'evaluate') return async (...evaluateArgs) => {
          const record = { argumentCount: evaluateArgs.length, secondArgument: evaluateArgs[1] ?? null, thirdArgument: evaluateArgs[2] ?? null, start: Date.now() };
          calls.evaluations.push(record);
          try { return await instance.evaluate(...evaluateArgs); }
          catch (error) { record.error = error.message; throw error; }
          finally { record.elapsedMs = Date.now() - record.start; }
        };
        return typeof instance[method] === 'function' ? instance[method].bind(instance) : instance[method];
      }});
      return wrap(real);
    };
  }});
}
const css = '<style>body{font:16px Arial;padding:24px;background:#f7f8fa;color:#1d2129}.arco-empty{padding:32px;background:white;border:1px solid #e5e6eb}.arco-table{border-collapse:collapse;background:white;width:100%}th,td{padding:16px;text-align:left;border:1px solid #e5e6eb}</style>';
const table = '<table class="arco-table"><thead><tr><th>Record</th><th>Status</th></tr></thead><tbody><tr><td>Loaded audit record</td><td>Ready</td></tr></tbody></table>';
async function main() {
  const oldHelper = extract(baseline, 'original');
  const newHelper = extract(patched, 'current');
  await diagnostics();
  if (process.argv.includes('--diagnostics-only')) return;
  const browserPath = path.join(root, 'audit-artifacts/base-final-closeout-2026-11-13/dependency-validation/browsers/chromium_headless_shell-1254/chrome-headless-shell-win64/chrome-headless-shell.exe');
  const browser = await pw.chromium.launch({ headless: true, executablePath: browserPath });
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const errors = [];
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  page.setDefaultTimeout(30000);
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  log({ kind: 'environment', node: process.version, playwright: depRequire('@playwright/test/package.json').version, typescript: ts.version, eslint: depRequire('eslint/package.json').version, browser: browser.version(), browserPath, sourceBase: 'ae2fa81d9903d63b4bec8f01d61082f48a999e2f' });
  try {
    for (const [name, factory, shouldReject] of [['original-detachment', oldHelper, true], ['corrected-detachment', newHelper, false]]) {
      await page.setContent(css + '<div class="arco-empty">Loading transient unknown text</div>' + table.replace('class="arco-table"', 'class="arco-table" style="display:none"'));
      const calls = { attempts: 0, visibility: [], evaluations: [] };
      const wrapped = interceptDetachment(page, calls);
      const start = Date.now();
      let rejected = false;
      let error = null;
      try { await factory(30000)(wrapped); } catch (caught) { rejected = true; error = caught.message; }
      const elapsedMs = Date.now() - start;
      log({ kind: 'test', name, rejected, elapsedMs, calls, error });
      assert.equal(rejected, shouldReject);
      assert.equal(calls.detachedAfterVisible, true);
      assert.equal(calls.visibility[0], true);
      assert.equal(await page.locator('.arco-table').isVisible(), true);
      if (shouldReject) {
        assert.equal(calls.evaluations[0].argumentCount, 2);
        assert.equal(calls.evaluations[0].thirdArgument, null);
        assert.ok(elapsedMs >= 29000 && elapsedMs < 35000, 'Original must exhaust30s instead of intended2s');
      } else {
        assert.equal(calls.evaluations[0].argumentCount, 3);
        assert.deepEqual(calls.evaluations[0].thirdArgument, { timeout: 2000 });
        assert.ok(calls.evaluations[0].elapsedMs >= 1900 && calls.evaluations[0].elapsedMs < 5000);
        assert.ok(elapsedMs < 6000 && calls.attempts >= 2, 'Corrected helper must recover via existing bounded retry');
      }
    }
    for (const [name, body, reject] of [['known-empty', '<div class="arco-empty">暂无登录日志</div>', false], ['populated-table', table, false], ['unknown-empty', '<div class="arco-empty">Unexpected persistent empty state</div>', true]]) {
      await page.setContent(css + body);
      for (const [viewportName, viewport] of [['desktop', { width: 1280, height: 720 }], ['mobile', { width: 390, height: 844 }]]) {
        await page.setViewportSize(viewport);
        await page.screenshot({ path: path.join(__dirname, name + '-' + viewportName + '.png'), fullPage: true });
      }
      const start = Date.now();
      let rejected = false;
      let error = null;
      try { await newHelper(3000)(page); } catch (caught) { rejected = true; error = caught.message; }
      log({ kind: 'test', name, rejected, elapsedMs: Date.now() - start, error });
      assert.equal(rejected, reject);
    }
    assert.equal(errors.length, 0);
    log({ kind: 'result', outcome: 'PASS', tests: 5, browserErrors: errors, visualScope: 'Rendered controlled regression fixtures only; no product UI change or polish claim', worktreeFileSHA256: hash(fs.readFileSync(helperPath, 'utf8')) });
  } finally {
    await context.tracing.stop({ path: path.join(__dirname, 'browser-trace.zip') });
    await browser.close();
    fs.writeFileSync(path.join(__dirname, 'results.json'), JSON.stringify(outputs, null, 2) + '\n');
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });


