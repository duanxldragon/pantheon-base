# Local Claude bounded smoke helper repair

## Original user task

Repair the confirmed smoke readiness evaluate argument defect in the isolated fix/smoke-empty-readiness worktree; modify only the assigned helper and prove the detached-empty race using the exact helper in a real browser. Root owns final review and delivery.

## Backend and final prompt

Backend: installed local Claude Code binary, normal permissions. Invocation: prompt.txt piped to D:/cache/npm-global/node_modules/@anthropic-ai/claude-code/bin/claude.exe -p --output-format text. No dangerous flags or permission bypass used. Exit0.
Repair one authorized, reversible smoke helper defect and preserve unrelated files.

You are implementing one authorized change in D:/workspace/go/pantheon-platform/.wt-base-smoke-readiness on branch fix/smoke-empty-readiness. You are not alone in this workspace; do not revert others. Own ONLY frontend/tests/smoke/system/system-pages-helpers.ts.

Read applicable AGENTS.md. In expectPageBodyReady the current call emptyNode.evaluate((element) => element.textContent ?? '', { timeout: 2000 }) incorrectly passes timeout as the browser function argument. Playwright Locator.evaluate expects the options as its third argument. Update ONLY this call to emptyNode.evaluate((element) => element.textContent ?? '', undefined, { timeout: 2000 }) using existing multiline formatting. Preserve comments, pageEmptyTexts, selectors, assertions, retries, timeout values, product UI/API and gates. No fullfile formatting, no other file writes, no commit/push/merge/branch cleanup, no dangerous flags or global permission bypass. Minimum complexity: one native API argument correction. Native Codex runs regression verification after your edit.

Return exact changed lines and explain why the third argument restores the already intended2000ms bound when .arco-empty detaches after isVisible. If normal permissions prevent editing, report without bypassing. Use absolute worktree path for edit.


## Raw CLI output

```text
"ark-code-latest" isn't described by this version's model catalog; update Claude Code, or map it with behavesAs on a modelPicker row (or modelOverrides, if it is a provider id of a model this version knows). Until then auto-compact keeps this session within 200k tokens (the context window it assumes); if the model accepts more, append [1m] to the model name for 1M, or set CLAUDE_CODE_MAX_CONTEXT_TOKENS to its real window; CLAUDE_CODE_DISABLE_UNKNOWN_MODEL_WINDOW_ENFORCEMENT=1 restores the previous wait-for-the-API behavior.
[claude-code:unrecognized_model] {"model":"ark-code-latest","query_source":"sdk"}
Done. The other modified files (`.harness/`, `docs/`, `CHANGELOG.md`, untracked evidence dir) belong to the parallel release-preparation work — I touched none of them; my write is the single owned file, one line changed (`2 +-`).

## Exact changed lines

`D:\workspace\go\pantheon-platform\.wt-base-smoke-readiness\frontend\tests\smoke\system\system-pages-helpers.ts`, inside `expectPageBodyReady` (line 775):

```diff
-    const emptyText = await emptyNode.evaluate((element) => element.textContent ?? '', {
+    const emptyText = await emptyNode.evaluate((element) => element.textContent ?? '', undefined, {
       timeout: 2000,
     });
```

Nothing else changed: comments, `pageEmptyTexts`, selectors, assertions, `toPass` retries, and the 2000 value are all preserved. No commit/push/branch operations.

## Why the third argument restores the intended 2000 ms bound

Playwright's signature is `Locator.evaluate(pageFunction, arg?, options?)` — `timeout` is read **only** from the third argument.

- **Before:** `{ timeout: 2000 }` landed in the second slot, `arg`. Playwright serializes it and passes it as the page function's second parameter — but the arrow function declares only `(element)`, so the object is silently discarded. TypeScript can't flag this: a one-parameter function is assignable to a two-parameter function type, and a plain object is a valid serializable arg. With the options slot absent, `evaluate` runs on its default timeout (0 = no timeout).
- **The race:** `isVisible()` can resolve true on Arco's transient loading `.arco-empty`, which then detaches when the table mounts. `evaluate` auto-retries locator resolution for the detached node; with no options-level cap it waits on the unbounded default instead of failing fast, so `toPass` never gets its quick retry and the call burns the 30 s test budget the comment warns about.
- **After:** explicit `undefined` occupies the arg slot (idiomatic "no argument" placeholder, matching Playwright's own docs pattern) and `{ timeout: 2000 }` reaches the options slot. A detached `.arco-empty` now makes `evaluate` reject with a `TimeoutError` at exactly 2000 ms; `toPass` catches it and retries, by which point the empty is gone, `isVisible()` is false, and the callback returns cleanly. The 2000 ms bound was always the author's intent — the value was simply delivered to the wrong parameter.

## Verification performed

- Prettier canonical output matches the edited hunk exactly (no diff in the `evaluate` region; new line is 99 chars, within `printWidth: 100`, keeping the existing multiline object style).
- The remaining `prettier --check` warnings are **pre-existing on HEAD** (multi-line function signatures at lines 460–641, from the npx-fetched 3.10.1 vs. the file's older formatting) and are outside my hunk; the repo's `format` script only globs `src/**`, not `tests/`.
- `git diff` confirms a one-line, one-file change.

Skipped / risk: no full smoke run, tsc, or eslint — this worktree has no `node_modules`, and the task assigns regression verification to native Codex. The edit is a positional-argument correction with no type-shape change, so type safety rests on Playwright's standard three-arg overload rather than a local compile.

```

## Concise summary

Claude implemented the exact one-line third-argument fix. Native Codex reviewed the diff and runs exact-source strict TypeScript/ESLint/diff checks and real-browser regression separately. Claude's statement about other modified files is not adopted as an inventory fact; native git status and scoped diff are authoritative. Runtime claims in the advisor output are advisory until native evidence verifies them.

## Action items / next steps

- Retain native runtime regression, screenshots and trace in this external artifact directory.
- Hand the stable one-line diff and evidence to the parent for independent review, candidate reseal and delivery.
