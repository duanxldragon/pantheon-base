# Smoke empty-readiness correction verification

Outcome: PASS. One repository source line changed: frontend/tests/smoke/system/system-pages-helpers.ts:775 now passes undefined as Locator.evaluate's second argument and {timeout:2000} as its third. No selectors, empty-text allowlist, timeout values, retries, APIs, product UI or gate settings changed.

Ownership: native lane + local Claude adapter owned only that helper and this external sr509 directory. Root coordinates parent task packet, independent review, governance, reseal, commit/PR/CI/release and worktree cleanup. Governance files visible in shared worktree status belong to the root lane and were neither edited nor reverted here.

Minimum complexity rung: native API argument correction. This is base-owned shared smoke tooling; browser behavior is runtime-sensitive. No schema/DDL, security, audit or i18n product behavior changes.

## Exact source identity

- Base commit: ae2fa81d9903d63b4bec8f01d61082f48a999e2f.
- Final worktree file SHA256: 0e2c20882e7fb20ad5884c64dc85388ca8acd2ecdab074e8887520dc19a59981.
- Final Git blob: 9c04901c2bae7244264dc33f1fbaff896b7d7e67.
- Parent Git source is extracted via git show; final worktree source is read from the exact file. TypeScript AST selects the exact expectPageBodyReady declaration and pageEmptyTexts declaration (source lines750 and37). Both selected source and CommonJS transpilation are retained with SHA256 hashes in results.json.
- Runtime does not use a handwritten helper copy. The only browser interception wraps real Page/Locator objects, removes the actual DOM empty after a native isVisible returns true, and forwards native evaluate arguments unchanged.

## Fresh validation commands

From this directory:

```
../dependency-validation/toolchain/node-v24.22.3-win-x64/node.exe --check regression.cjs
../dependency-validation/toolchain/node-v24.22.3-win-x64/node.exe regression.cjs
```

The script runs these scoped diagnostics before browser verification:

- ESLint10.14.0 API lintFiles on the exact modified worktree helper with the unmodified repository eslint.config.js rules. Existing already-verified dependencies are reused by resolving imports to their installed paths. Zero errors or warnings; raw eslint.txt.
- TypeScript6.0.3 createProgram, strict/noEmit, on the exact AST-extracted helper + pageEmptyTexts with real Playwright1.65.0 Page/expect types. Zero diagnostics; raw typescript.txt. Ordinary repository tsc excludes tests, so this explicitly covers the changed helper.
- git diff --check on the worktree. PASS; raw diff-check.txt and exact patch.diff.
- Real headless Chromium158.0.8127.18, revision1254, Playwright1.65.0, Node24.22.3. No dependency installation or manifest mutation.

## Real browser results

| Scenario | Result | Runtime evidence |
|---|---|---|
| Original helper; visible empty detaches before evaluate | Expected rejection | Whole case30046ms; native evaluate30012ms Timeout30000; second argument contains timeout and third absent |
| Corrected exact helper; same detachment | PASS | Native evaluate rejects after2015ms at Timeout2000; existing toPass retries; helper resolves2171ms; visibility true then false, two attempts |
| Known persistent empty (暂无登录日志) | PASS |43ms |
| Populated table | PASS |12ms |
| Unknown persistent empty | Expected rejection |2996ms; original allowlist assertion receives false |

The external harness gives native toPass an explicit per-case budget:30000ms for the detachment comparison and3000ms for persistent-state checks. This only bounds this regression harness; the extracted helper bytes and repository timeout/retry settings remain unchanged. Native page default timeout30000 reproduces CI's lost short timeout.

Browser console errors/page errors: none. Exact raw records: browser.txt and results.json. Real browser trace: browser-trace.zip. Desktop1280x720 and mobile390x844 screenshots retained for known/unknown empty and populated table. Native visual inspection of known-empty-desktop.png and populated-table-mobile.png confirms visible states with readable unclipped content. These are controlled regression fixtures, not application screenshots or product polish claims. Product layout, styling and responsiveness were not changed.

## Local Claude artifact and first harness attempt

Normal-permission installed local Claude Code ran -p, received the bounded prompt in prompt.txt, implemented only the one-line source repair, and exited0. Prompt and raw output retained in .omx/artifacts/ask-claude-readiness-20261113.md plus claude.txt. No dangerous flags or permission bypass.

The first external harness attempt mistakenly supplied toPass timeout through expect.configure, which only supports ordinary assertion timeout. That attempt still measured the original real evaluate timeout30022ms but let its subsequent retry return. Native source inspection corrected the harness to supply the deadline to native toPass options; final five-case rerun passes. The failed harness output remains explicitly retained as browser-attempt1.txt/results-attempt1.json, not represented as a product or helper failure.

## Remaining scope and stop condition

No backend/authenticated full application suite was run in this isolated lane. The targeted real DOM reproducer covers the helper defect and preserves rejection behavior. Parent owns hosted Smoke Sanity/full checks and independent review before merging/releasing. Source bytes remain stable after Claude exit and final git hash check; ready for parent consumer reseal. No commit/push/merge/cleanup performed here.
