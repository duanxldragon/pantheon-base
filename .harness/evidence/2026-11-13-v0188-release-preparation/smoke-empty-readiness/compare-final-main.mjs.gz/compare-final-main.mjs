import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const taskRoot=path.dirname(fileURLToPath(import.meta.url));
const sourceRoot=path.resolve(process.argv[2]??'D:/workspace/go/pantheon-platform/pantheon-base');
const label=process.argv[3]??'final-main';
if(!/^[a-z0-9-]+$/u.test(label))throw new Error('Invalid evidence label');
const descriptorPath=path.join(taskRoot,'sealed-final/candidate-descriptor.json');
const descriptorBytes=fs.readFileSync(descriptorPath);
const descriptor=JSON.parse(descriptorBytes);
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const git=(...args)=>execFileSync('D:/Git/mingw64/bin/git.exe',['-C',sourceRoot,...args],{encoding:'utf8'}).trim();
const headBefore=git('rev-parse','HEAD');
const files=[];
const mismatches=[];
for(const item of descriptor.files){try{const bytes=fs.readFileSync(path.join(sourceRoot,item.path));const actual={path:item.path,bytes:bytes.length,sha256:sha(bytes)};files.push(actual);if(actual.bytes!==item.bytes||actual.sha256!==item.sha256)mismatches.push({expected:item,actual});}catch(error){mismatches.push({path:item.path,error:error.code});}}
const headAfter=git('rev-parse','HEAD');
if(headBefore!==headAfter)throw new Error('Source HEAD changed during comparison');
const result={createdAt:new Date().toISOString(),sourceRoot,head:headAfter,status:git('status','--porcelain','--untracked-files=no'),candidateIdentity:descriptor.candidateIdentity,descriptorSha256:sha(descriptorBytes),selectedLeaves:descriptor.files.length,matchedLeaves:descriptor.files.length-mismatches.length,aggregateSha256:sha(Buffer.from(JSON.stringify(files))),expectedAggregateSha256:descriptor.aggregateSha256,allSelectedBytesMatch:mismatches.length===0,mismatches,files,officialConsumption:false,scope:'Byte binding only; final clean main/source review/hosted gates/official assets/runtime release acceptance remain separately required'};
fs.writeFileSync(path.join(taskRoot,`${label}-byte-binding.json`),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({head:result.head,candidateIdentity:result.candidateIdentity,selectedLeaves:result.selectedLeaves,matchedLeaves:result.matchedLeaves,aggregateSha256:result.aggregateSha256,allSelectedBytesMatch:result.allSelectedBytesMatch,mismatches},null,2));
if(mismatches.length)process.exitCode=1;

