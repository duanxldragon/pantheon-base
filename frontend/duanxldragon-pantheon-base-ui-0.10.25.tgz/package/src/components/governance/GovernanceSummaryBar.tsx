import React from 'react';
import { Typography } from '@arco-design/web-react';

export interface GovernanceSummaryMetric {
  key: string;
  label: React.ReactNode;
  value: React.ReactNode;
  description?: React.ReactNode;
  className?: string;
  role?: React.AriaRole;
  tabIndex?: number;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
  onKeyDown?: React.KeyboardEventHandler<HTMLDivElement>;
}

export interface GovernanceSummaryBarProps {
  icon?: React.ReactNode;
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  description?: React.ReactNode;
  metrics: GovernanceSummaryMetric[];
  action?: React.ReactNode;
  className?: string;
}

const GovernanceSummaryBar: React.FC<GovernanceSummaryBarProps> = ({
  icon,
  eyebrow,
  title,
  description,
  metrics,
  action,
  className,
}) => {
  // 治理栏只保留两行（功能域 + 标题）；description 仅在无标题时兜底，
  // 详细说明统一放治理抽屉，避免三行文案挤占页面高度。
  const mainTitle = title || description;

  return (
    <section
      className={['page-panel', 'governance-summary-bar', className].filter(Boolean).join(' ')}
    >
      <div className="governance-summary-bar__copy">
        {eyebrow ? <span className="governance-summary-bar__eyebrow">{eyebrow}</span> : null}
        {mainTitle ? (
          <div className="governance-summary-bar__title-row">
            {icon ? <span className="governance-summary-bar__icon">{icon}</span> : null}
            <Typography.Text className="governance-summary-bar__title">{mainTitle}</Typography.Text>
          </div>
        ) : null}
      </div>
      <div className="governance-summary-bar__metrics">
        {metrics.map((item) => (
          <div
            key={item.key}
            className={['governance-summary-bar__metric', item.className].filter(Boolean).join(' ')}
            role={item.role}
            tabIndex={item.tabIndex}
            onClick={item.onClick}
            onKeyDown={item.onKeyDown}
          >
            <span className="governance-summary-bar__metric-label">{item.label}</span>
            <strong className="governance-summary-bar__metric-value">{item.value}</strong>
            {item.description ? (
              <span className="governance-summary-bar__metric-desc">{item.description}</span>
            ) : null}
          </div>
        ))}
      </div>
      {action ? <div className="governance-summary-bar__action">{action}</div> : null}
    </section>
  );
};

export default GovernanceSummaryBar;
